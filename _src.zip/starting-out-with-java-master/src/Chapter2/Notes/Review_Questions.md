1. **Describe what the phrase *"self-documenting program"* means.** 
  
  
  
  
2. **What is meant by *"Case-sensitive"*? Why it is important for a programmer to know 
  that Java is a case-sensitive language?**
  
   
   

3. **Explain how the *print* and *println* methods are related to the *System* class
   and the *out* object.**
  
   
   
  
4. **Explain what programming style means. Why should your programming style be consistent?**
    
   The term Programming Style is referred to visual rules or guidelines used 
   when writing the source code.
   Particularly indentations, blank lines, spaces etc. 
   Which tell a programmer important information about the program. 
 
5. 